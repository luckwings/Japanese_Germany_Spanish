class ScraperType:
    BROWSER = "browser"
    REQUEST = "request"
