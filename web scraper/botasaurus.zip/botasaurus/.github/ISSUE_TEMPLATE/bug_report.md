---
name: Bug report
about: Report a problem to help us improve
---

<!--
If an error occurs, please zip the 'error_log/' folder created by Botasaurus and include it here. Kindly also attach code to reproduce the error.
-->
