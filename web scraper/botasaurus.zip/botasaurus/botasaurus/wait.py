class Wait:
    SHORT = 4
    LONG = 8
    VERY_LONG = 16