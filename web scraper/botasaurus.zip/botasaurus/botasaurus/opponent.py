class Opponent:
    PERIMETER_X = "PerimeterX"
    CLOUDFLARE = "Cloudflare"
