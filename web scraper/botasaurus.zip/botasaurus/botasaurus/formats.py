class Formats:
    JSON = 'JSON'
    CSV = 'CSV'
    JSON_AND_CSV = ['JSON', 'CSV']
