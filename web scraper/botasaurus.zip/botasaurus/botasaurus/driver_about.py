class AboutBrowser:
    def __init__(self, window_size=None, user_agent=None, profile=None, proxy=None,lang=None, beep=False, is_new=True ):
        self.window_size = window_size
        self.user_agent = user_agent
        self.profile = profile
        self.proxy = proxy
        self.lang = lang
        self.beep = beep
        self.is_new = is_new
        
        self.retry_attempt = 0
        self.is_retry = False
        self.is_last_retry = False
