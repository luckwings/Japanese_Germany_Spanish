class Usage:
    def put(task_name, url):
        pass