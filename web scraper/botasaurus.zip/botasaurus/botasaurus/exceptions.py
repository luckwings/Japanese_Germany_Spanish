
class CloudflareDetection(Exception):
    pass
