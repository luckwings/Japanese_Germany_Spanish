# Got Scraping

fork of Got Scraping that default export functions from got-scraping